# Tarea 3

Generar numeros aleatorios

```bash
cd generators
make
```

Ejecutar las pruebas

```bash
python3 evaluator.py
```